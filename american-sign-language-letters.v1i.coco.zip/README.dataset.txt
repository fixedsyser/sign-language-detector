# american-sign-language-letters > 2023-08-03 6:46pm
https://universe.roboflow.com/pranav-atote-ebc3y/american-sign-language-letters-dtfq9

Provided by a Roboflow user
License: CC BY 4.0

